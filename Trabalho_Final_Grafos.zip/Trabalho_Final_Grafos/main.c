/***************************************************************
* Aluno: Antônio Marques Souza Seixas
* Aluno: João Pedro Monteiro Ferreira
* Curso: Bacharelado (Licenciatura) em Ciências da Computação
*
* Lista 2: Grafos - Implementações
*
* Estrutura de Dados II - 2025 -- DACC/UNIR, - Profa.Carolina Watanabe
* Compilador: gcc.exe (Rev2, Built by MSYS2 project) versão: 14.2.0
* Sistema Operacional: Windows 11
***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grafos.h"
// #include "auxiliares/listaD.h"

//no Main estão apenas os testes realizados para cada algoritmo

int main(){
    Grafo *G;
    Grafo *tree;
    G = lerGrafo("grafosT/graph_3.txt");
    printf ("Grafo lido como teste:\n");

    printGrafo(G, 0);
    printf ("\nDepth-first search (DFS): \n\n");
    DFSearch(G);

    // printCores(G);

    printf ("\nBreadth-first search (BFS): \n\n");
    BFSearch(G);
    printf ("===============================\n");

    printf ("\nMinimun Spanning Tree with prim algorithm:\n\n");
    tree = prim(G);
    printGrafo(tree, 0);

    Grafo *Path;

    printf ("===============================\n");
    printf ("\nFloyd Warshall algorithm:\n \n");
    Path = FloydW(G);
    printGrafo(Path, 0);
    printf ("===============================\n");

    printf ("\nDijkstra algorithm:\n\n");    
    dijkstra(G, 0);
    printf ("===============================\n");
    Grafo *K;
    printf ("\nbfsCaminhoMinimo:\n \n");
    bfsCaminhoMinimo(G, 0);
    
    // printGrafo(G, 0);
    // printGrafo(G, 0);
    // printCores(G);
    
    return 0;
}