/***************************************************************
* Aluno: Antônio Marques Souza Seixas
* Aluno: João Pedro Monteiro Ferreira
* Curso: Bacharelado (Licenciatura) em Ciências da Computação
*
* Lista 2: Grafos - Implementações
*
* Estrutura de Dados II - 2025 -- DACC/UNIR, - Profa.Carolina Watanabe
* Compilador: gcc.exe (Rev2, Built by MSYS2 project) versão: 14.2.0
* Sistema Operacional: Windows 11
***************************************************************/

#include "grafos.h"
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "auxiliares/listaD.h"

#include <stdio.h>
#include <stdlib.h>
#include <float.h>  // Para usar DBL_MAX como "infinito"

#define INF DBL_MAX  // Definição de infinito

void dijkstra(Grafo *g, int origem) {
    if (g == NULL) return;

    double *dist = (double *)malloc(g->numVertices * sizeof(double));
    int *anterior = (int *)malloc(g->numVertices * sizeof(int));  // Para reconstruir o caminho

    // Inicializa as distâncias e o vetor de cores (tudo não visitado)
    for (int i = 0; i < g->numVertices; i++) {
        dist[i] = INF;
        g->cores[i] = 'a';  // 'a' significa não visitado
        anterior[i] = -1;
    }

    dist[origem] = 0;  // A distância da origem para ela mesma é 0

    for (int i = 0; i < g->numVertices - 1; i++) {
        // Encontra o vértice com menor distância e ainda não visitado
        int u = -1;
        double minDist = INF;
        for (int j = 0; j < g->numVertices; j++) {
            if (g->cores[j] == 'a' && dist[j] < minDist) {
                minDist = dist[j];
                u = j;
            }
        }

        if (u == -1) break;  // Se não há mais vértices alcançáveis, termina

        g->cores[u] = 'm';  // Marca o vértice como visitado

        // Atualiza as distâncias dos vizinhos de u
        for (int v = 0; v < g->numVertices; v++) {
            if (g->vertices[u][v] != 0 && g->cores[v] == 'a') {
                double novaDist = dist[u] + g->vertices[u][v];
                if (novaDist < dist[v]) {
                    dist[v] = novaDist;
                    anterior[v] = u;  // Atualiza o caminho
                }
            }
        }
    }

    // Imprime as menores distâncias
    printf("Distancias a partir do vertice %d:\n", origem);
    for (int i = 0; i < g->numVertices; i++) {
        if (dist[i] == INF) {
            printf("Vertice %d: Inacessivel\n", i);
        } else {
            printf("Vertice %d: %.2lf\n", i, dist[i]);
        }
    }

    // Reseta as cores para permitir outras buscas no grafo
    for (int i = 0; i < g->numVertices; i++) {
        g->cores[i] = 'a';
    }

    free(dist);
    free(anterior);
}
//--------------------------------------------------

void descolorirGrafo(Grafo *g){
    for(int i=0; i<g->numVertices; i++){
        g->cores[i] = 'a';
    }
}

int addEdgeList(Lista *L, int x, int y, double peso){
    tipo_elemnto aux;
    aux.peso = peso;aux.x = x; aux.y = y;
    inserir_ordenada_peso(L, aux);
}

void addAresta(Grafo *g, int x, int y, double peso){
    g->vertices[x][y] = peso;
    g->vertices[y][x] = peso;    
}
Grafo* criarGrafo(int numV){
    Grafo *p = (Grafo *)malloc(sizeof(Grafo));
    double **matr = (double **)malloc(sizeof(double * )*numV);
    for(int i=0; i<numV; i++){
        matr[i] = (double *)calloc(numV, sizeof(double ));
    }
    
    char *cors = (char*)malloc(sizeof(char)*numV);
    for(int i=0; i<numV; i++){
        cors[i]='a';
    }

    p->vertices = matr;
    p->cores = cors;
    p->numArestas = 0;
    p->numVertices = numV;
    return p;
}

int escolheAresta(Lista *arestas, Grafo *tree){
    int x = arestas->head->info.x;
    int y = arestas->head->info.y;
    double peso = arestas->head->info.peso;

    tree->vertices[x][y] = peso;
    tree->vertices[y][x] = peso;

    remover_inicio(arestas);
    return x;
}

Grafo* prim(Grafo* grafo) {
    int numV = grafo->numVertices;
    int pai[numV];   // Armazena a MST resultante
    double chave[numV]; // Chaves usadas para escolher arestas de menor peso
    int visitado[numV]; // Indica se um vértice já está na MST

    for (int i = 0; i < numV; i++) {
        chave[i] = DBL_MAX; // Inicializa todas as chaves com infinito
        visitado[i] = 0;    // Nenhum vértice foi incluído na MST
    }
    
    chave[0] = 0;   // Começamos pelo vértice 0
    pai[0] = -1;    // O primeiro nó não tem pai

    for (int count = 0; count < numV - 1; count++) {
        int u = -1;
        double min = DBL_MAX;

        // Encontra o vértice com a menor chave ainda não incluído na MST
        for (int v = 0; v < numV; v++) {
            if (!visitado[v] && chave[v] < min) {
                min = chave[v];
                u = v;
            }
        }

        visitado[u] = 1; // Inclui u na MST

        // Atualiza os valores das chaves dos vértices adjacentes a u
        for (int v = 0; v < numV; v++) {
            if (grafo->vertices[u][v] && !visitado[v] && grafo->vertices[u][v] < chave[v]) {
                pai[v] = u;
                chave[v] = grafo->vertices[u][v];
            }
        }
    }

    
    Grafo *tree = criarGrafo(grafo->numVertices);
    for (int i = 1; i < numV; i++) {
        addAresta(tree, pai[i], i, grafo->vertices[i][pai[i]]);
        // printf("%d - %d (Peso: %.1lf)\n", pai[i], i, grafo->vertices[i][pai[i]]);
    }
    return tree;
}

void BFSearch(Grafo *g){//imprime a ordem de travessia no grafo
    
    // o Algoritmo que vimos:
    //     Dado G(V,A), conexo: 
    //     escolher uma raiz s de V 
    //     definir uma fila Q, vazia 
    //     marcar s 
    //     inserir s em Q 
    //     enquanto Q não vazia faça 
    //     	seja v o 1°. vértice de Q 
    //     	para cada w pertencente à ListaAdjacencia(v) faça                  
    //     		se w é não marcado então    
    //     			visitar (v,w) 
    //     			marcar w 
    //     			inserir w em Q 
    //     		senão se w pertence à Q então 
    //     			visitar (v,w)   /*w alcançado por outro caminho*/        
    //     		/*senão já processou w e portanto (w,v)*/ 
    //     	/*fim_para*/  
    //         retirar v de Q 
    //         /*fim_enquanto*/
    
    //usarei como cores 'm' para marcado e 'a' para não marcado
    if(g==NULL){return;}
    Lista fila;definir(&fila);tipo_elemnto valor;valor.chave=0;
    tipo_elemnto aux;

    printf ("[");
    g->cores[valor.chave] = 'm';//marca s
    inserir_inicio(&fila, valor);

    printf ("%d", valor.chave);
    
    while(vazia(&fila)!=1){
        valor.chave = fila.head->info.chave;//valor é o primeiro valor da fila
        // printf ("no while\n");
        for(int j=0; j<g->numVertices; j++){//para cada w na lista de adjascência de v

            if(g->vertices[valor.chave][j] !=0){//os não nulos são os da lista de adjacência
                if(g->cores[j] != 'm'){//se ele é não marcado
                    // printf ("etrou\n");
                    // printf (" (%d, %d);", valor.chave+1, j+1);//visita v,w
                    g->cores[j] = 'm';
                    printf (", %d", j);
                    aux.chave = j;
                    inserir_final(&fila, aux);
                }
                //a parte de baixo é necessária para o caso de fazer a visita (printf)

                // else if(buscar(&fila, j)!=NULL){
                //     // printf ("ELSE\n");
                //     // printf (" (%d, %d);", valor.chave+1, j+1); 
                // }
                // printf ("dentro\n");
            
            }
        }
        remover_inicio(&fila);
    }
    descolorirGrafo(g);
    printf ("]\n");
}

void DFS(Grafo *g, int vertice) {
    if (g == NULL) return;

    printf(" %d", vertice);
    g->cores[vertice] = 'm'; 

    for (int j = 0; j < g->numVertices; j++) {
        if (g->vertices[vertice][j] != 0 && g->cores[j] != 'm') {  
            DFS(g, j); 
        }
    }
}

void DFSearch(Grafo *g) {
    if (g == NULL) return;

    descolorirGrafo(g); 

    printf("[");
    DFS(g, 0); 
    printf(" ]\n");

    descolorirGrafo(g);
}


Grafo* lerGrafo(const char* nomeArquivo){
    
    //abrindo o arquivo
    FILE *graph;
    graph = fopen(nomeArquivo, "rt");
    if (graph == NULL)
    {
        printf("Problemas na CRIACAO do arquivo\n");
        return NULL;
    }
    int numV;
    int numA=0;
    fscanf(graph, "%d ", &numV);

    char linha[50];  
    int x, y;
    double z=1;
    int valoresLidos;
    int escolha;
    double **Verts;

    // Lendo a primeira linha do arquivo
    if (fgets(linha, sizeof(linha), graph) != NULL) {
        // Tentando ler 3 valores
        valoresLidos = sscanf(linha, "%d %d %lf", &x, &y, &z);

        if (valoresLidos == 3) {
            // printf("Formato 'x y z' detectado: x=%d, y=%d, z=%lf\n", x, y, z);
            Verts = (double **)malloc(numV * sizeof(double *));
            for (int i = 0; i < numV; i++) {
                // Verts[i] = (double *)malloc(numV * sizeof(double));
                Verts[i] = (double *)calloc(numV, sizeof(double));
                
                // for (int j = 0; j < numV; j++) {
                //     Verts[i][j] = 0.0;

                // }
            }
            Verts[x][y] = z;
            Verts[y][x] = z;
            numA++;
            escolha = 3;
        } else if (valoresLidos == 2) {
            // printf("Formato 'x y' detectado: x=%d, y=%d\n", x, y);
            Verts = (double **)malloc(numV * sizeof(double *));
            for (int i = 0; i < numV; i++) {
                // Verts[i] = (double *)malloc(numV * sizeof(double));
                Verts[i] = (double *)calloc(numV, sizeof(double));
                
                // for (int j = 0; j < numV; j++) {
                //     Verts[i][j] = 0.0;
                // }
            }
            Verts[x][y] = z;
            Verts[y][x] = z;
            numA++;
            escolha = 2;
        } else {
            printf("Erro: formato inválido na primeira linha:\n");
            printf ("%s\n", linha);
            return NULL;
        }
    }

    //dependendo de escolha, continuamos a leitura do arquivo de forma diferente
    switch(escolha){
        case 3:
        //leitura de grafo ponderado
            while(fscanf(graph, "%d %d %lf", &x, &y, &z) == 3){  
                if (x >= 0 && x < numV && y >= 0 && y < numV) {  
                    Verts[x][y] = z;
                    Verts[y][x] = z;
                    numA++;
                    // Verts[x][y] = z;  
                } else {  
                    printf("Erro: Aresta (%d, %d) fora dos limites!\n", x, y);  
                    return NULL;
                }  
            }
        break;
        //leitura de grafo NÃO ponderado
        case 2:
            while(fscanf(graph, "%d %d", &x, &y) == 2){  
                if (x >= 0 && x < numV && y >= 0 && y < numV) {  
                    Verts[x][y] = 1;  
                    Verts[y][x] = 1;
                    numA++;
                } else {  
                    printf("Erro: Aresta (%d, %d) fora dos limites!\n", x, y);  
                    return NULL;
                }  
            }
        break;
    }
    
    char *cors = (char*)malloc(sizeof(char)*numV);
    for(int i=0; i<numV; i++){
        cors[i]='a';
    }

    Grafo *g;
    // printf ("tudo ok\n");

    g = (Grafo *)malloc(sizeof(Grafo));
    g->numArestas = numA;
    g->numVertices = numV;
    g->vertices = Verts;
    g->cores = cors;
    fclose(graph);
    
    // printf ("tudo ok 2\n");
    return g;
}

void printGrafo(Grafo *g, int precisao){
    if(precisao<0)
        return;
    for(int i=0; i<g->numVertices; i++){
        for(int j=0; j<g->numVertices; j++){
            printf ("%*.*lf ", precisao+3, precisao, (g->vertices)[i][j]);
        }printf ("\n");
    }
}
void printCores(Grafo *g){
    for(int i=0; i<g->numVertices; i++){
        printf ("%3c ", g->cores[i]);
    }printf ("\n");
}

void inicializarDist(int numV, double **grafo, double **dist) {
    for (int i = 0; i < numV; i++) {
        for (int j = 0; j < numV; j++) {
            if (i == j) {
                dist[i][j] = 0;  // Distância de um nó para ele mesmo é 0
            } else if (grafo[i][j] != 0) {
                dist[i][j] = grafo[i][j];  // Se há aresta, usa o peso dela
            } else {
                dist[i][j] = INT_MAX;  // Se não há aresta, define como infinito
            }
        }
    }
}

Grafo *FloydW(Grafo *g){
    Grafo *dist;
    dist = criarGrafo(g->numVertices); 
    inicializarDist(g->numVertices, g->vertices, dist->vertices);

    int n = g->numVertices;
    for(int k=0; k<n; k++){
        for(int i=0; i<n; i++){
            for(int j=0; j<n; j++){
                if(dist->vertices[i][j] > dist->vertices[i][k] + dist->vertices[k][j])
                dist->vertices[i][j] = dist->vertices[i][k] + dist->vertices[k][j];
            }
        }
    }

    return dist;
}


//pppppppppppppppppppppppppppppppppppppppppppppp

// Função auxiliar para criar um conjunto Union-Find
UnionFind* criarUnionFind(int n) {
    UnionFind* uf = (UnionFind*) malloc(sizeof(UnionFind));
    uf->pai = (int*) malloc(n * sizeof(int));
    uf->rank = (int*) calloc(n, sizeof(int));
    for (int i = 0; i < n; i++) {
        uf->pai[i] = i;
    }
    return uf;
}

// Busca o representante do conjunto
int find(UnionFind* uf, int v) {
    if (uf->pai[v] != v) {
        uf->pai[v] = find(uf, uf->pai[v]); // Compressão de caminho
    }
    return uf->pai[v];
}

// União por rank
void unionSets(UnionFind* uf, int v1, int v2) {
    int raiz1 = find(uf, v1);
    int raiz2 = find(uf, v2);
    
    if (raiz1 != raiz2) {
        if (uf->rank[raiz1] > uf->rank[raiz2]) {
            uf->pai[raiz2] = raiz1;
        } else if (uf->rank[raiz1] < uf->rank[raiz2]) {
            uf->pai[raiz1] = raiz2;
        } else {
            uf->pai[raiz2] = raiz1;
            uf->rank[raiz1]++;
        }
    }
}

// Função de comparação para ordenação das arestas por peso
int compararArestas(const void *a, const void *b) {
    Aresta *arestaA = (Aresta *)a;
    Aresta *arestaB = (Aresta *)b;
    return (arestaA->peso > arestaB->peso) - (arestaA->peso < arestaB->peso);
}

// Algoritmo de Kruskal
Grafo* kruskal(Grafo* g) {
    if (!g) return NULL;

    // Criar lista de arestas
    int numArestas = g->numArestas;
    Aresta* arestas = (Aresta*) malloc(numArestas * sizeof(Aresta));

    int index = 0;
    for (int i = 0; i < g->numVertices; i++) {
        for (int j = i + 1; j < g->numVertices; j++) {
            if (g->vertices[i][j] > 0) { // Existe uma aresta
                arestas[index].origem = i;
                arestas[index].destino = j;
                arestas[index].peso = g->vertices[i][j];
                index++;
            }
        }
    }

    // Ordenar as arestas por peso
    qsort(arestas, numArestas, sizeof(Aresta), compararArestas);

    // Criar a MST (árvore geradora mínima)
    Grafo* mst = (Grafo*) malloc(sizeof(Grafo));
    mst->numVertices = g->numVertices;
    mst->numArestas = 0;
    

    mst->vertices = (double**) malloc(mst->numVertices * sizeof(double));


    mst->cores = (char*) malloc(mst->numVertices * sizeof(char));
    memset(mst->cores, 0, mst->numVertices); // Nenhum vértice visitado

    for (int i = 0; i < mst->numVertices; i++) {
        mst->vertices[i] = (double*) calloc(mst->numVertices, sizeof(double));
    }

    // Criar estrutura Union-Find para os vértices
    UnionFind* uf = criarUnionFind(g->numVertices);

    int arestasAdicionadas = 0;
    for (int i = 0; i < numArestas && arestasAdicionadas < g->numVertices - 1; i++) {
        Aresta aresta = arestas[i];

        if (find(uf, aresta.origem) != find(uf, aresta.destino)) {
            mst->vertices[aresta.origem][aresta.destino] = aresta.peso;
            mst->vertices[aresta.destino][aresta.origem] = aresta.peso;
            unionSets(uf, aresta.origem, aresta.destino);
            mst->cores[aresta.origem] = 1; // Marcando como visitado
            mst->cores[aresta.destino] = 1;
            mst->numArestas++;
            arestasAdicionadas++;
        }
    }

    // Liberar memória temporária
    free(arestas);
    free(uf->pai);
    free(uf->rank);
    free(uf);

    return mst;
}
#include <stdio.h>
#include <stdlib.h>
#include "auxiliares/listaD.h"
#include "grafos.h"

void bfsCaminhoMinimo(Grafo *g, int origem) {
    if (g == NULL) return;

    int *dist = (int *)malloc(g->numVertices * sizeof(int));
    int *anterior = (int *)malloc(g->numVertices * sizeof(int));  
    Lista fila;
    definir(&fila);
    
    // Inicializa distâncias e cores
    for (int i = 0; i < g->numVertices; i++) {
        dist[i] = -1;       // -1 significa inatingível
        g->cores[i] = 'a';  // 'a' significa não visitado
        anterior[i] = -1;   // Para reconstrução do caminho
    }

    dist[origem] = 0;
    g->cores[origem] = 'm';  // Marca como visitado
    tipo_elemnto v;
    v.chave = origem;
    inserir_inicio(&fila, v);

    while (!vazia(&fila)) {
        int atual = fila.head->info.chave;
        remover_inicio(&fila);

        for (int vizinho = 0; vizinho < g->numVertices; vizinho++) {
            if (g->vertices[atual][vizinho] != 0 && g->cores[vizinho] == 'a') { 
                int peso = g->vertices[atual][vizinho]; // Peso da aresta

                // Se a distância ainda não foi definida ou podemos melhorar a distância
                if (dist[vizinho] == -1 || dist[vizinho] > dist[atual] + peso) {
                    dist[vizinho] = dist[atual] + peso;   // Atualiza a distância
                    anterior[vizinho] = atual;           // Guarda o caminho
                    g->cores[vizinho] = 'm';             // Marca como visitado
                    v.chave = vizinho;
                    inserir_final(&fila, v);
                }
            }
        }
    }

    // Imprime as distâncias mínimas
    printf("\nDistancias minimas a partir do vertice %d:\n", origem);
    for (int i = 0; i < g->numVertices; i++) {
        if (dist[i] == -1) {
            printf("Vertice %d: Inacessivel\n", i);
        } else {
            printf("Vertice %d -> Distancia: %d\n", i, dist[i]);
        }
    }

    // Reseta as cores para futuras buscas
    for (int i = 0; i < g->numVertices; i++) {
        g->cores[i] = 'a';
    }

    free(dist);
    free(anterior);
}
// void bfsCaminhoMinimo(Grafo *g, int origem) {
//     if (g == NULL) return;

//     int *dist = (int *)malloc(g->numVertices * sizeof(int));
//     int *anterior = (int *)malloc(g->numVertices * sizeof(int));  // Para reconstruir caminhos
//     Lista fila;
//     definir(&fila);
    
//     // Inicializa as distâncias e cores
//     for (int i = 0; i < g->numVertices; i++) {
//         dist[i] = -1;      // -1 significa inatingível
//         g->cores[i] = 'a'; // 'a' significa não visitado
//         anterior[i] = -1;  // Para reconstrução do caminho
//     }

//     dist[origem] = 0;
//     g->cores[origem] = 'm'; // Marca como visitado
//     tipo_elemnto v;
//     v.chave = origem;
//     inserir_inicio(&fila, v);

//     while (!vazia(&fila)) {
//         int atual = fila.head->info.chave;
//         remover_inicio(&fila);

//         for (int vizinho = 0; vizinho < g->numVertices; vizinho++) {
//             if (g->vertices[atual][vizinho] != 0 && g->cores[vizinho] == 'a') { // Se há aresta e não foi visitado
//                 g->cores[vizinho] = 'm';   // Marca como visitado
//                 dist[vizinho] = dist[atual] + 1; // Atualiza distância
//                 anterior[vizinho] = atual; // Guarda o caminho
//                 v.chave = vizinho;
//                 inserir_final(&fila, v);
//             }
//         }
//     }

//     // Imprime as menores distâncias
//     printf("Distancias a partir do vertice %d:\n", origem);
//     for (int i = 0; i < g->numVertices; i++) {
//         if (dist[i] == -1) {
//             printf("Vertice %d: Inacessivel\n", i);
//         } else {
//             printf("Vertice %d: %d arestas\n", i, dist[i]);
//         }
//     }

//     // Reseta as cores para futuras buscas
//     for (int i = 0; i < g->numVertices; i++) {
//         g->cores[i] = 'a';
//     }

//     free(dist);
//     free(anterior);
// }